"""Domain research tests."""
